//
//  blueViewController.swift
//  mydrawer
//
//  Created by iMac on 2018/12/11.
//  Copyright © 2018年 iMac. All rights reserved.
//

import UIKit

class blueViewController:  BaseViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addSlideMenuButton()
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
