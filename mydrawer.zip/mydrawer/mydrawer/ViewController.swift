//
//  ViewController.swift
//  mydrawer
//
//  Created by iMac on 2018/12/11.
//  Copyright © 2018年 iMac. All rights reserved.
//

import UIKit

class ViewController:  BaseViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addSlideMenuButton()
        
        // Do any additional setup after loading the view, typically from a nib.
    }


}

